/**
 * 
 */
/**
 * 类/接口注释
 * 
 * @author hailin1.wang@downjoy.com
 * @createDate 2016年8月26日
 * 
 */
package com.hlin.distributedLock.conf;